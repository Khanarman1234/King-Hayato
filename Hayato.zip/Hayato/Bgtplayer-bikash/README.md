<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<h2 align="center">
      ʙɪᴋᴀꜱʜ ᴍᴜꜱɪᴄ 2.0
</h2>


<p align="center">
  <img src="https://telegra.ph/file/4d7a997a6c8c4eb406829.jpg">
</p>


<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## What's the work of this bot ? :
Best Smart Voice Chat Music Bot For All Telegram Groups or Channels This Bot Support Video play Or Audio Play Both ||

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## Multiple deployment options are available :
First you have to fork this repo and star this repo for motivating us and without forking it can occur an error while you deploying your apps so fork this first 

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## 🔗 Features :

- Pyrogram 2.0
- Feel no lag while playing songs
- Zero downtime
- Fast Download Song From Server
- Py-tgcalls Updated
- Fastest vc bot on telegram
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## Basic Bot Commands :

- `/play <song name>` - play song you requested
- `/vplay <song name>` - play video you requested
- `/song <song name>` - download songs you want quickly
- `/ping` - Bot Online OR Offine
- `/pause` - pause song play
- `/resume` - resume song play
- `/skip` - play next song
- `/end` - stop music play

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## Mandatory Bot Variable's: 

- ``API_ID``
- ``API_HASH``
- ``BOT_TOKEN``
- ``MUSIC_BOT_NAME``
- ``MONGO_DB_URI``
- ``OWNER_ID``
- ``STRING_SESSION``

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## Tutorial for workflow deployment :

<a href="https://youtu.be/_nZT5lhcL8U)"><img src="https://img.shields.io/badge/Kaali%20Linux-black.svg?style=for-the-badge&logo=Youtube"></a>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## ⚠️ Deploy On Workflow :

To deploy on workflow you need to import codes of that repository which u want to deploy on github workflow. for detailed process checkout Kaali-Linux tutorial above of this repository.

Necessary Variables To Host On Workflow given below :

- ``GIT_EMAIL`` - Your github mail 
- ``GIT_NAME``  - Your github username
- ``BOT_REPO``  - Your bot repository which u want to deploy 
- ``GIT_TOKEN`` - your github access token it acts like a password for your github account

<a
href="https://github.com/new/import"><img src="https://img.shields.io/badge/Deploy%20On%20Workflow-black?style=for-the-badge&logo=Github" width="220"
hieght="38.30" /></a>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

### Generate your string session through termux choose always Pyrogram-2.0 :

<a href="https://github.com/AdityaHalder/PGV2-STRING"> <img src="https://img.shields.io/badge/Termux%20Session-brown?style=for-the-badge&logo=github" width="220" height="38.45"/>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## ⚠️ Okteto Deployment :

<h4>Click the button below to deploy on Okteto!</h4>

<a href="https://cloud.okteto.com/deploy?repository=https://github.com/BikashHalderNew/Bgtplayer">
  <img
src="https://img.shields.io/badge/Deploy%20On%20Okteto-lightpink?style=for-the-badge&logo=Okteto" width="220""/>
</a>
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

##  Mogenius Deployment :

<h4>Click the button below to deploy on Mogenius!</h4>

<a href="https://mogenius.com">
  <img
src="https://img.shields.io/badge/Deploy%20On%20Mogenius-grey?style=for-the-badge&logo=Mogenius" width="220""/>
</a>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## ᴅᴇᴘʟᴏʏ ᴏɴ ʀᴀɪʟᴡᴀʏ 🚈 :
Check Out [Necessary Variables Here](https://github.com/BikashHalderNew/Bgtplayer/blob/bikash/Internal)
fill these vars

<a href="https://railway.app/new/template?template=https://github.com/BikashHalderNew/Bgtplayer-Deploy&envs=STRING_SESSION,BOT_TOKEN,OWNER_ID,MONGO_DB_URI,API_ID,API_HASH"><img src="https://railway.app/button.svg" alt="Deploy on Railway" /></a>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

##  🔗 Deploy On Scalingo :
<h4>Click On the below button to deploy on scalingo<h4>

<a
href="https://scalingo.com/deploy?template=https://github.com/BikashHalderNew/Bgtplayer"><img src="https://img.shields.io/badge/Deploy%20On%20Scalingo-silver?style=for-the-badge&logo=Scalingo" width="220"
hieght="38.30" /></a>
  
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

##  🔗 Deploy On Uffizzi :
<h4>Click On the below button to deploy on uffizzi platform!<h4>

<a
href="https://uffizzi.com/deploy?template=https://github.com/BikashHalderNew/Bgtplayer"><img src="https://img.shields.io/badge/Deploy%20On%20Uffizzi-gold?style=for-the-badge&logo=Uffizzi" width="220"
hieght="38.30" /></a>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## 🔗 Deploy On Heroku :

<h4>Click the button below to deploy Bikash Music Bot on Heroku!</h4>    

<a
href="https://heroku.com/deploy?template=https://github.com/BikashHalderNew/Bgtplayer"><img src="https://img.shields.io/badge/Deploy%20On%20Heroku-seagreen?style=for-the-badge&logo=Heroku" width="220"
hieght="38.30" /></a>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## Clever Cloud Deployment :

<a
href="https://www.clever-cloud.com/deploy?template=https://github.com/BikashHalderNew/Bgtplayer"><img src="https://img.shields.io/badge/Deploy%20Clever%20Cloud-blue?style=for-the-badge&logo=Clever" width="220"
hieght="38.30" /></a>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## ᴅᴇᴘʟᴏʏ ᴏɴ ᴠᴘꜱ 📡 :

- Get your [Necessary Variables](https://github.com/BikashHalderNew/Bgtplayer/blob/bikash/Internal)

- Upgrade and Update by :
``sudo apt-get update && sudo apt-get upgrade -y``
- Install Ffmpeg by :
``sudo apt-get install python3-pip ffmpeg -y``
- Install required packages by :
``sudo apt-get install python3-pip -y``
- Install pip by :
``sudo pip3 install -U pip``
- Install Node js by :
``curl -fssL https://deb.nodesource.com/setup_19.x | sudo -E bash - && sudo apt-get install nodejs -y && npm i -g npm``
- Clone the repository by :
``git clone https://github.com/BikashHalderNew/Bgtplayer && cd Bgtplayer``
- Install requirements by :
``pip3 install -U -r Installer``
- Fill your variables in the env by :
vi.env<br>
Press ``I`` on the keyboard for editing env<br>
Press ``Ctrl+C `` when you're done with editing env and ``:wq`` to save the env<br> and to exit press ``:qa``
- Install tmux to keep running your bot when you close the terminal by :
``sudo apt install tmux && tmux``
- Finally run the bot by :
``python3 -m Bikash``
- For getting out from tmux session : Press | ``Ctrl+b`` | and then d<br>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## Now its time to give some credits ✨ :

- [BGT](https://github.com/BikashHalder) For everything 
- [Aditya-Halder](https://github.com/AdityaHalder) For fixed errors
- [YUKKI-MUSIC](https://github.com/TeamYukki) For Yukki Music Bot
- [Dan](https://github.com/pyrogram) For pyrogram
- [Laky](https://github.com/pytgcalls) For py-tgcalls

- Thanks For Vivan Fixed All Errors 

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## Support & Updates ⚡ :

<a href="https://t.me/bgt_chat"><img src="https://img.shields.io/badge/Join-Group%20Support-darkblue.svg?style=for-the-badge&logo=Telegram"></a> <a href="https://t.me/BikashGadgetsTech"><img src="https://img.shields.io/badge/Join-Updates%20Channel-darkblue.svg?style=for-the-badge&logo=Telegram"></a>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## 🖥️ Owner Of This Repository :

[![Bikash Halder](https://te.legra.ph/file/840fed0100164af249bb8.jpg)](https://t.me/BikashHalder)

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## Also support  our youtube channel by subscribing it :

<a href="https://youtube.com/channel/UCUkj6FFzdsOO5acUXVOEECg"><img src="https://img.shields.io/badge/Youtube%20Channel-red.svg?style=for-the-badge&logo=Youtube"></a>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

#### ᴋᴀɴɢ ɪᴛ ᴡɪᴛʜ ᴘʀᴏᴘᴇʀ ᴄʀᴇᴅɪᴛꜱ ᴇʟꜱᴇ ʏᴏᴜʀ ᴍᴜᴍ ᴍɪɴᴇ...
